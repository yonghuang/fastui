fastDev(function() {
	fastDev.Core.ControlBus.compile();
});