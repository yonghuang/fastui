﻿*1.5.1.1----2013.03.21 16:14*
*功能增强Improvements
1.Componet中实现了数据隐身属性mapper
2.数据模块中增加结构化类型数据多叉树(新增fastDev.Data.Tree、fastDev.Data.Node)

*Bug修复Fixes
1.修复下拉框被通用方法定位后造成的面板高度不能随内容自适应问题
2.修复弹窗类控件在IE6下页面存在滚动条时锁屏遮罩层高度错误的问题
3.修复复选框数组选中兼容问题。
4.修复弹窗类控件在开启动画后，动画效果正在进行中而页面已经销毁时，有可能出现js执行错误的问题

*性能优化Optimization
1.删除Record和Field对象，新增Model对象，优化数据对象化性能
2..废除数据集的后台交互功能，将数据集定位为纯数据处理对象。改为使用代理关联数据集，并触发代理的请求数据方法来填充远程数据至数据集
3.手风琴、纵向导航、选项卡 、树、下拉树、复选框、表单都对应底层不再使用dataset的get,select(带字符串查询条件),update方法，使用优化后的方法。
4.表单使用代理请求数据，不再使用数据集。（主推1.3格式数据）
5.DatePicker使用函数模板创建

*1.5.1.0----2013.02.22 16:04*
*功能增强Improvements
1.Component新增支持函数模板的功能
2.DatePicker控件，新增跨Iframe展现的功能
3.Select控件，新增跨Iframe展现的功能
4.AutoComplete控件，新增跨Iframe展现的功能
5.Form增加得到initSource数据的方法getInitData
6.SelectTree控件，新增跨Iframe展现的功能
7.TextBox控件之textarea文本域，可配置调节大小，以兼容原生文本域可调节大小的特性
8.表单的数据全面兼容1.3数据格式
9.纵向导航增加节点的个性化样式
10.纵向导航自定义点击事件如果返回false,则删除A链接的地址，只执行事件。

*Bug修复Fixes
1.修复Button初始化禁用能点击的bug
2.修复DataGrid同时配置了隐藏列与行内信息功能时数据表头与表数据对不齐问题
3.修复表单在没有initSource数据源和dataSource数据源的情况下表单的事件不能得到子控件实例的bug
4.修复tree控件在使用静态数据源时多个与数据源相关的方法不能正常使用的问题。
5.修复tree展开层次的bug
6.修复tree自定义跟节点时只有一条数据时不出来的bug
7.修复下拉树点开后点击窗体其他地方没有关闭
8.修复下拉树拖拽后下拉树位置没有变化问题


*性能优化Optimization
1.Button控件优化为使用函数模板创建
2.Select控件优化为使用函数模板创建
3.Toolbar控件优化为使用模板函数创建
4.SelectTree性能优化，样式优化
5.SelectTree控件优化为使用函数模板创建
6.Tree不再使用未经优化性能dataset数据源而直接使用json格式数据源提升性能
7.TextBox控件优化为使用函数模板创建
8.弹窗类控件优化为使用函数模板创建
9.新建的消息框（alert、prompt、confirm、save）将重用之前的控件实例从而提升性能

*1.5.0.6----2013.02.01 13:59*
*功能增强Improvements
1.树性能进行了优化，ie浏览器下性能提升了一半
2.树新增加了点击单选框和点击复选框事件，新增加了选中某个节点的方法
3.下拉树设置只读时使其的样式改变成灰色
4.DataGrid新增addRows(批量新增行),updateRows(批量修改行),delRows(批量删除行),clean(删除当前所有数据)方法
5.DataGrid新增filterData(界面数据过滤)方法
6.新增DataGrid获取当前修改信息getAllModifyInfo参数reset，以防止重复获取修改值
7.应项目组需求，fastDev.notice增加可配置onBeforeAutoClose回调（先于onBeforeClose调用），以区别于onBeforeClose回调（该回调无论是否自动关闭都会调用）。
8.树添加是否有文本选中的方法getSelectedIds
9.tabs控件在ie6下只打开一个iframe,ie7下打开超过3个iframe后不再新增iframe而是改变第一个iframe的地址
10.tabs控件ie6下添加一种只有一个iframe的模式。
11.树异步时也支持id,pid是数字格式的数据

*Bug修复Fixes
1.修复Window控件在某些跨级展现场景下可能会出现默认的zIndex层级关系不正确的问题
2.修复树增加pid为根节点的节点时没反映的问题，处理好异步树增加节点样式问题。
3.修复日历控件过滤可用日期值时，若当前待选日期超过拟选月份的最大日期时，可能造成死循环的问题。
4.修复tabs在ie6下面添加第一个页面不显示的问题
5.修复tabs在ie7下多个tab切换不显示的问题

*1.5.0.5----2013.01.18 11:21*
*功能增强Improvements
1.表单提交前事件放在submit方法最前面，以便获取数据
2.复选框组增加是否验证通过方法
3.优化单选框组的得到值返回值为字符串
4.树得到值方法性能优化
5.DataSet新增changeIndex方法用于改变数据索引
6.DataGrid新增addFirstRow与addLastRow方法，addRow方法扩展第三个可选参数用于指定数据插入后的位置
7.ChooseList控件，中部按钮面板区域按钮控件点击事件回调作用域由当前ChooseList实例变为当前按钮实例，点击回调函数接收参数依次为event（点击事件对象）、chooselist（当前ChooseList实例）
8.弹窗类控件，工具栏和底部按钮栏上的按钮的点击事件回调的作用域由当前弹窗实例变为当前按钮实例，回调参数依次变更为event（点击事件对象）、dialog（当前弹窗实例）、window（弹窗内部子页面window对象）、fastDev（弹窗内部子页面的fastDev对象）
9.窗体类控件，新增empty、append、showContent、hideContent、showToolbar、hideToolbar、getToolbar、showFooter、hideFooter、getFooter公用方法。resize与move支持动画效果，resize支持宽高为auto的配置参数。优化内容自适应等。
10.窗体类控件，新增bodyStyle配置参数，可自定义内容区域的行内样式。新增showSizeTips配置参数，可在拖拽调节窗体大小时标示窗体的实时尺寸，方便开发人员确定窗体的合适大小。
11.DataGrid新增设置宽度setWidth、设置高度setHeight以及同时设置高宽的reseize()方法
12.弹窗类控件（Window、Dialog、MessageBox）新增getInstance方法，可获取以弹窗内容文本形式声明的fastui控件的实例
13.树，下拉树，手风琴，纵向导航，选项卡的鼠标操作类事件的增加第一个参数为event
14.tabs选项卡没显示的iframe页面点击后才加载

*Bug修复Fixes
1.修复手风琴动画效果问题
2.修复fastDev.tips到IE6下面宽度未自适应的问题
3.Box类控件，精确宽高计算，修正各浏览器由于用户代理样式不同导致输入框溢出的问题
4.修复tabs关闭后当前选中项为前一个，前一个没有为后一个
5.修复tabs在ie6中addTab报错

*1.5.0.4----2013.01.09 15:07*
1.复选框单选框组的总宽度自动计算
2.数据总线增加外部可配置数据读取器，可用来做数据的统一处理
3.AutoComplete修复控件构造时未初始化失焦标识值而导致控件第一次未获取焦点也会触发失焦验证的问题
4.DatePicker控件，变更只读状态时不弹日历面板为弹日历面板，但不改变当前已选值
5.Tabs拖拽和左右滚动的更新了算法并增加动画效果
6.手风琴增加动画效果
7.修复fastDev.prompt输入消息框文本内容过长时不自适用宽高且产生滚动条的问题
8.修复fastDev.notice通知框点击关闭按钮时，onBeforeClose和onAfterClose事件未调用的问题
9.ChooseList控件新增显示加载图标功能，可通过showLoading属性开启远程数据加载时显示进度图标，通过loadingMsg定义图标提示信息
10.修正ChooseList控件、树搜索展现示例中，取消已选结果往搜索结果树中回添节点时，有可能产生重复节点的问题
11.修复Window控件宽高属性值指定为"auto"，自适应窗体宽高过程中宽高最值仅依据当前可视区域宽高而忽略用户自己指定的宽高最值的问题
12.Window控件新增overlayOpacity属性，可自定义锁屏时遮罩层的透明度
13.新增异常管理器ExceptionManager
14.数据总线新增绑定页面所有请求时完成时的回调句柄方法bindReqComplete
15.DataGrid新增上移moveUp和下移moveDown方法

*1.5.0.3----2013.01.07 08:41*
1.修复DataGrid内置保存方法提交数据未编码问题
2.修复Select计算可用高度不准问题
3.改进Window内容宽高自适部分，解决超长连续非单词英文字符不自动断行的问题，处理方式为内容宽度超过800px则强制分解字符进行断行
4.修复Window控件内部子页面加载完成后未解绑相关事件导致刷新内部子页面时窗口重复闪烁提醒的问题
5.DatePicker控件实现输入框的onchange事件
6.下拉树控件setValue方法是能触发onchange事件
7.下拉树控件html配置属性时改成只用一层div
8.简短提示信息标签(fastDev.tips)新增内容图标、动画效果等
9.通知消息框(fastDev.notice)新增position参数配置，可定义消息框的弹出方向（可支持8个方向）
10.修复控件库中各控件enabledInitProxy设置为false时不会触发onAfterLoadInit、onAfterInitRender事件以及不执行constructItems方法问题
11.修复控件库中各控件enabledDataProxy设置为false时不会触发onAfterLoadData、onAfterDataRender事件以及不执行setValue方法问题
12.ChooseList控件，调整相关参数，修正界面有有些许未对齐的问题
13.修复新增加的tabs点击与滚动位置问题
14.修复控件隐藏属性问题
15.针对设置了allowDelayLoad(延时加载属性)的大数据表格加载性能做了进一步优化，解决IE6、7下仍可能出现的运行速度较慢问题
16.解决DataGrid在IE6、IE7下宽度计算错误出现横向滚动条问题
17.树文本过长自动截取功能，非样式，文本截取加title
18.修复fastDev.isComponent判断可能失误问题
19.修复DataGrid行数据融合算法的Bug

*1.5.0.2----2012.12.28 09:24*
1.修复数据代理提交数据至后台服务后返回数据没有进入数据总线问题
2.修复下拉框IE10下读取首选项不正确以及上移下移可能造成死循环问题
4.表单获取值方法不编码，提交的值才编码。
5.修复tabs添加了很多很多是滚动条点击一下后失效问题
6.修复选框组支持number值
7.修复Box类fire方法Bug
8.DataGrid新增以回车键结束行内编辑功能
9.修复复选框组和下拉树的原生事件问题
10.修复tabs添加会刷新问题
11.选人控件样式更新
12.tabs添加方法更新
13.下拉树增加可直接配置initSource和直接使用表单的initSource数据源
14.表单重置方法先调清空方法
15.纵向导航样式问题
16.增强Record对象，使其支持深层结构数据
17.控制总线增加队列实例池，使控件库内控件支持按顺序依次加载
18.修复DataGrid的delRow方法会导致部分渲染器渲染失败问题
19.表单控制请求顺序问题
20.窗体类控件新增动画效果支持，且在相关API上可通过定义动画参数来自定义动画展现效果
21.完善窗体类控件内容自适应部分
22.窗体类控件新增内部子页面懒加载机制，并可通过load()方法动态加载新的子页面
23.窗体类控件新增setContent()方法，可用来动态更新显示的文本内容（可含HTML标签以及控件声明）
24.下拉树setvalue支持传数字类型参数
25.DataGrid新增onRowDblClick(行双击)、onCellClick(列单击)、onCellDblClick(列双击)事件
26.完善表单提交给值问题
27.下拉树弹出层增加高度设置与增加点击文本框后再设置弹出层位置功能
28.修复DataGrid横向滚动条滚动后导致表格的标题与数据对不齐问题
29.修复树添加删除后的父节点样式问题
30.修复表单提交前修改action问题，表单后台取值问题
31.修复下拉树只读属性设置

*1.5.0.1----2012.12.21 9:00*
1.修正IE10下HTML模式编译不完整问题
2.修复纵向导航设置当前活动id的bug
3.修复富文本框设置id方法的bug
4.修改树得到所有节点方法名
5.添加输入类控件对原生事件的全面支持
6.修复按钮自定义点击事件句柄问题
7.修复下拉框没有获得焦点也会调用失去焦点事件问题
8.修复工具栏removeItem之后还可以getItem到子项的问题
9.修复最大数字、最小数字、自定义正则验证错误
10.修复Ajax验证时错误提示不消失问题
11.Button的onBtnClick改成onclick，下拉树的点击事件
12.修复Box验证代码问题
13.修复多个控件的代码警告
14.修复纵向导航getItemById
15.修复tabs选项卡少的情况下也出来滚动耳朵样式的东西
16.修复DataGrid行高亮Bug
17.修复DataGrid行高不同时数据部分和表头对不齐问题
18.修复DataGrid操作列在无数据行仍然显示问题
19.修复下拉框弹出面板高度不能根据内容自适应高度问题
20.修复表单的刷新initSource方法
21.复选框增加reset和修改clean方法
22.修复下拉树样式问题
23.修复Window控件JS初始加载时，获取顶层父窗口对象时可能导致异常的BUG
24.AutoComplete控件，onValueChange事件名统一随父类控件变更为onchange事件名
25.复选框和下拉树得到焦点后才能触发失去焦点事件

*1.5.0----2012.12.12 12:00*
1.修复CheckBoxGroup验证时报错的问题
2.修复DataGrid行内编辑后调用增加、删除、删除选中行接口，数据未回写问题
3.修复DataGrid新增行再进行行内编辑后，更改样式显示不正常问题
4.修复From验证报错问题
5.修复DataGrid宽度计算问题
6.修复Proxy提交数据时多加变量名data问题
7.修复Ajax提交防止缓存参数被后台Action错误解析问题
8.修复表单特殊字符提交问题
9.修复总页数在查不到数据时为0的问题
10.修复手风琴宽度问题
11.修复AutoComplete初始值时在IE下会聚焦的问题
12.修复DataBus数据读取判断数据类型错误问题