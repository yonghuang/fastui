fastDev.apply({
	_seqFlow : ["ready", "construct", "init"],
	/**
	 * 通过类路径获取类
	 * @param {String} classPath 类路径
	 * @return {Object}
	 * @member fastDev
	 * @private
	 */
	getClassForPath : function(classPath) {
		var Class = window;
		fastDev.each(classPath.split("."), function(i, name) {
			if(!( Class = Class[name])) {
				return false;
			}
		});
		return Class.Class || Class;
	},
	/**
	 * 类定义方法
	 * @param {String} classPath 类路径
	 * @param {Object} config 类配置
	 * @member fastDev
	 */
	define : function(classPath, config) {
		if(!(/(.*)\.(.*)/g.exec(classPath))) {
			return;
		}
		var Class, supClass, prop, ctor,
		// 根据类路径建立所属命名空间
		space = fastDev.namespace(RegExp.$1);

		// 解析继承关系
		Class = fastDev.parseExtend(config.extend);

		// 注册类
		fastDev.Core.ClassManager.regClass(classPath, Class, config.alias);

		// 继承父类配置项及全局配置
		fastDev.each("_options _global".split(" "), function(i, name) {
			prop = ( prop = Class[name]) ? fastDev.clone(prop) : {};
			Class[name] = fastDev.apply(prop, config[name]);
			delete config[name];
		});

		// 扩展类属性以及方法
		fastDev.apply(Class, config);

		// 如果不是静态类则创建构造方法
		if( ctor = config.ctor) {
			if(ctor === true) {
				ctor = fastDev.makeCtor(classPath);

				ctor.Class = Class;
			} else if(!fastDev.isFunction(ctor)) {
				ctor = undefined;
			}
		}
		// 填充命名空间
		space[RegExp.$2] = ctor || Class;
	},
	/**
	 * 创建构造方法
	 * @private 
	 */
	makeCtor : function(classPath) {
		return function(options) {
			return fastDev.create(classPath, options);
		};
	},
	/**
	 * 解析继承关系
	 * @private 
	 */
	parseExtend : function(supClass) {
		var Class;
		if(supClass) {
			supClass = fastDev.Core.ClassManager.getClass(supClass);
			Class = fastDev.extend(supClass);
		} else {
			Class = {};
		}
		return Class;
	},
	/**
	 * 类实例创建
	 * @param {String} className 类名
	 * @param {Object} settings 示例配置信息
	 * @return {Object}
	 * @member fastDev
	 */
	create : function(className, settings) {
		// 解析类名
		var Class = fastDev.Core.ClassManager.getClass(className);
		try {
			// 创建类实例
			var instance = fastDev.clone(Class),
			// 继承父类配置
			options = fastDev.clone(instance._options),
			// 继承父类全局空间
			global = fastDev.clone(instance._global);
			// 读入用户配置
			instance._options = fastDev.apply(options, settings);
			instance._global = global;
			// 执行实例初始化
			fastDev.constructInstance(instance);
			return instance;
		} catch(e) {
			if(!Class) {
				throw "类[" + className + "]不存在，无法创建实例";
			} else {
				throw e;
			}
		}
	},
	/**
	 * 类初始化流程控制
	 * @param {Object} instance 实例
	 * @return {Object}
	 * @private
	 * @member fastDev
	 */
	constructInstance : function(instance) {
		var options = instance._options, global = instance._global, name;
		for(var i = 0, flow = fastDev._seqFlow; name = flow[i++]; ) {
			fastDev.execAllSuperClassMethod(instance, name, options, global);
		}
		return instance;
	},
	/**
	 * 类继承方法
	 * @param {Object} supClass 父类
	 * @return {Object}
	 * @member fastDev
	 */
	extend : function(supClass) {
		var subClass = fastDev.clone(supClass);
		subClass.superClass = supClass;
		return subClass;
	},
	/**
	 * 从顶层父类开始依次执行指定方法
	 * @param {Object} context 实例对象
	 * @param {String} methodName 方法名称
	 * @member fastDev
	 * @private
	 */
	execAllSuperClassMethod : function(context, methodName) {
		var currContext = context,
		// 获取父类作用域
		superContext = context.superClass,
		// 构建流程方法执行队列,将当前作用域的流程方法添加至队列
		execQueue = [context[methodName]],
		// 缓存流程方法参数
		options = context._options, global = context._global,
		// 生成流程方法的回调方法名称
		handleName = fastDev.Util.StringUtil.capitalize(methodName);
		// 递归查找所有父类并把流程方法添加至队列
		while(superContext) {
			if(superContext[methodName] && context[methodName] !== superContext[methodName]) {
				execQueue.splice(0, 0, superContext[methodName]);
			}
			context = superContext;
			superContext = context.superClass;
		}
		// 触发流程方法执行之前事件
		fastDev.fire(options["onBefore" + handleName], currContext);

		for(var i = 0, method; method = execQueue[i]; i += 1) {
			// 从顶层父类开是执行流程方法
			method.call(currContext, options, global);
		}

		// 触发流程方法执行之后事件
		fastDev.fire(options["onAfter" + handleName], currContext);
	},
	/**
	 * 是否组件对象
	 * @param {Object} value
	 * @return {Boolean}
	 * @member fastDev
	 */
	isComponent : function(value) {
		return fastDev.Core.Base.isPrototypeOf(value);
	},
	/**
	 * 是否DomObject对象
	 * @param {Object} value
	 * @return {Boolean}
	 * @member fastDev
	 */
	isDomObject : function(value) {
		return fastDev.Core.DomObject.isPrototypeOf(value);
	}
});

/**
 * @class fastDev.Core.Base
 * @singleton
 */
fastDev.define("fastDev.Core.Base", {
	_options : {
		/**
		 * 控件准备方法调用之前执行
		 * @event
		 */
		onBeforeReady : fastDev.noop,
		/**
		 * 控件准备方法调用之后执行
		 * @event
		 */
		onAfterReady : fastDev.noop,
		/**
		 * 控件构造方法调用之前执行
		 * @event
		 */
		onBeforeConstruct : fastDev.noop,
		/**
		 * 控件构造方法调用之后执行
		 * @event
		 */
		onAfterConstruct : fastDev.noop,
		/**
		 * 控件初始化方法调用之前执行
		 * @event
		 */
		onBeforeInit : fastDev.noop,
		/**
		 * 控件初始化方法调用之后执行
		 * @event
		 */
		onAfterInit : fastDev.noop,
		/**
		 * 控件销毁方法调用之前执行
		 * @event
		 */
		onBeforeDestroy : fastDev.noop,
		/**
		 * 控件销毁方法调用之前执行
		 * @event
		 */
		onAfterDestroy : fastDev.noop
	},
	_global : {

	},
	/**
	 * 保存控件配置信息方法
	 * @param {JsonObject} config 配置信息
	 */
	setOptions : function(config) {
		fastDev.apply(this._options, config);
	},
	/**
	 * 获取控件配置信息方法
	 * @return {JsonObject} options
	 */
	getOptions : function() {
		return this._options;
	},
	/**
	 * 保存控件全局信息方法
	 * @param {JsonObject} config 配置信息
	 * @protected
	 */
	setGlobal : function(config) {
		fastDev.apply(this._global, config);
	},
	/**
	 * 获取控件全局信息方法
	 * @return {JsonObject} global
	 * @protected
	 */
	getGlobal : function() {
		return this._global;
	},
	/**
	 * 组件参数准备方法
	 * @param {Object} options 当前控件配置信息
	 * @param {Object} global 当前控件全局信息
	 * @protected
	 */
	ready : fastDev.noop,
	/**
	 * 组件构造方法
	 * @param {Object} options 当前控件配置信息
	 * @param {Object} global 当前控件全局信息
	 * @protected
	 */
	construct : fastDev.noop,
	/**
	 * 组件初始化方法
	 * @param {Object} options 当前控件配置信息
	 * @param {Object} global 当前控件全局信息
	 * @protected
	 */
	init : fastDev.noop,
	/**
	 * 组件销毁方法
	 * @param {Object} options 当前控件配置信息
	 * @param {Object} global 当前控件全局信息
	 */
	destroy : fastDev.noop

});

