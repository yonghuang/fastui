fastDev.namespace("fastDev.Util");

/**
 * 符串类型数据处理工具类
 * @class fastDev.Util.StringUtil
 * @author 袁刚
 * @singleton
 */
fastDev.Util.StringUtil = {
	/**
	 * 将str中的html符号转义
	 * @param {String} str 需要转义的字符串
	 * @return {String}
	 */
	unhtml : function(str) {
		return str ? str.replace(/[&<">]/g, function(m) {
			return {
			'<': '&lt;',
			'&': '&amp',
			'"': '&quot;',
			'>': '&gt;'
			}[m];
		}) : '';
	},
	/**
	 * 删除字符串首尾空格
	 * @param {String} str 字符串
	 * @return {String}
	 */
	trim : function(str) {
		return (str && str.replace) ? str.replace(/(^\s*)|(\s*$)/g, "") : str;
	},
	/**
	 * 删除字符串左边空格
	 * @param {String} str 字符串
	 * @return {String}
	 */
	ltrim : function(str) {
		return (str && str.replace) ? str.replace(/(^\s*)/g, '') : str;
	},
	/**
	 * 删除字符串右边空格
	 * @param {String} str 字符串
	 * @return {String}
	 */
	rtrim : function(str) {
		return (str && str.replace) ? str.replace(/(\s*$)/g, '') : str;
	},
	/**
	 * 去除HTML标签
	 * @param {String} str 待处理字符串
	 * @return {String}
	 */
	trimHtml : function(str) {
		return (str && str.replace) ? str.replace(/<(\S*?)[^>]*>.*?|< .*? \/>/g, "") : str;
	},
	/**
	 * 获取含中文字符串长度
	 * @param {String} str 字符串
	 * @return {Number}
	 */
	getChLength : function(str) {
		return (str && str.replace) ? str.replace(/[^\x00-\xff]/g, '..').length : 0;
	},
	/**
	 * 将以"-"分隔的日期格式字符串转换为日期对象
	 * @param {String} str 待处理字符串
	 * @return {Date}
	 */
	strParseDate : function(strdate) {
		return new Date(Date.parse(strdate.replace(/-/g, "/")));
	},
	/**
	 * 将目标字符串中可能会影响正则表达式构造的字符串进行转义。
	 * @param {string} source 待转换字符串
	 * @return {string}
	 * 给以下字符前加上“\”进行转义：.*+?^=!:${}()|[]/\
	 */
	escapeReg : function(source) {
		return String(source).replace(new RegExp("([.*+?^=!:\\${}()|[\\]\/\\\\])", "g"), '\\$1');
	},
	/**
	 * 对目标字符串进行html编码
	 * @param {string} source 目标字符串
	 * @return {string}
	 * 编码字符有5个：&<>"'
	 */
	encodeHTML : function(source) {
		return String(source).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, "&quot;").replace(/'/g, "&#39;");
	},

	/**
	 * 对目标字符串进行html解码
	 * @param {string} source 目标字符串
	 * @return {string}
	 */
	decodeHTML : function(str) {
		str = String(str).replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, "&");
		//处理转义的中文和实体字符
		return str.replace(/&#([\d]+);/g, function(_0, _1) {
			return String.fromCharCode(parseInt(_1, 10));
		});
	},
	/**
	 * 字符串第一个字符大写
	 * @param {String} str 待转换字符串
	 * @return {String}
	 */
	capitalize : function(all, letter) {
		if(letter) {
			return (letter + "").toUpperCase();
		} else {
			return all.replace(/./, function(str) {
				return str.toUpperCase();
			});
		}
	},
	/**
	 * 将一个带px、%、em的单位值转换为整型数值
	 * em单位以当前文档的字体样式（font-size）属性值转换
	 * 默认情况下，1em 等于 16px
	 * @param {String|Number} val 需要截除单位的值
	 * @param {Number} max 百分比数值转换时的被乘数
	 * @return {Number}
	 */
	stripUnits : function(val, max) {
		if(!!val || val === 0) {
			if( typeof val === 'number') {
				return parseFloat(val);
			}
			var num = /^(-?\d+\.?\d+|-?\d)(px|%|em)?$/.exec(val.toLowerCase().replace(/(^\s*)|(\s*$)/g, ''));
			if(!!num) {
				if(num[2] === '%') {
					return (max === 0 ? 0 : max || 100) * num[1] / 100;
				} else if(num[2] === 'em') {
					return num[1] * fastDev.Util.StringUtil.stripUnits(fastDev(document.body).css('font-size') || 16, 16);
				}
				return parseFloat(num[1]);
			}
		}
		return NaN;
	}
};

/**
 * 数字类型数据处理工具类
 * @class fastDev.Util.NumberUtil
 * @author 袁刚
 * @singleton
 */
fastDev.Util.NumberUtil = {
	/**
	 * 为目标数字添加逗号分隔
	 * @param {number} source 需要处理的数字
	 * @param {number} length (Optional) 两次逗号之间的数字位数，默认为3位
	 * @return {string}
	 */
	comma : function(source, length) {
		if(!length || length < 1) {
			length = 3;
		}

		source = String(source).split(".");
		source[0] = source[0].replace(new RegExp('(\\d)(?=(\\d{' + length + '})+$)', 'ig'), "$1,");
		return source.join(".");
	},

	/**
	 * 对目标数字进行0补齐处理
	 * @param {number} source 需要处理的数字
	 * @param {number} length 需要输出的长度
	 * @return {string}
	 */
	pad : function(source, length) {
		var pre = "",
		
		negative = (source < 0), string = String(Math.abs(source));

		if(string.length < length) {
			pre = (new Array(length - string.length + 1)).join('0');
		}

		return ( negative ? "-" : "") + pre + string;
	},
	/**
	 * 生成随机整数
	 * @param {number} min 随机整数的最小值
	 * @param {number} max 随机整数的最大值
	 * @return {number}
	 */
	randomInt : function(min, max) {
		return Math.floor(Math.random() * (max - min + 1) + min);
	}
};

/**
 * 日期对象处理工具类
 * @class fastDev.Util.DateUtil
 * @author 袁刚
 * @singleton
 */

fastDev.Util.DateUtil = {
	/**
	 * 对目标日期对象进行格式化
	 * @param {Date} date 日期对象
	 * @param {string} pattern 日期格式化规则
	 * @return {String}
	 * <p>格式表达式，变量含义:</p>
	 * <p>-yyyy: 带 0 补齐的四位年表示</p>
	 * <p>-yy: 带 0 补齐的两位年表示</p>
	 * <p>-MM: 带 0 补齐的两位月表示</p>
	 * <p>-M: 不带 0 补齐的月表示</p>
	 * <p>-dd: 带 0 补齐的两位日表示</p>
	 * <p>-d: 不带 0 补齐的日表示</p>
	 * <p>-hh: 带 0 补齐的两位 12 进制时表示</p>
	 * <p>-h: 不带 0 补齐的 12 进制时表示</p>
	 * <p>-HH: 带 0 补齐的两位 24 进制时表示</p>
	 * <p>-H: 不带 0 补齐的 24 进制时表示</p>
	 * <p>-mm: 带 0 补齐两位分表示</p>
	 * <p>-m: 不带 0 补齐分表示</p>
	 * <p>-ss: 带 0 补齐两位秒表示</p>
	 * <p>-s: 不带 0 补齐秒表示</p>
	 */
	format : function(date, pattern) {
		if(!fastDev.isString(pattern)) {
			return date.toString();
		}

		function replacer(patternPart, result) {
			pattern = pattern.replace(patternPart, result);
		}

		var pad = fastDev.Util.NumberUtil.pad, year = date.getFullYear(), month = date.getMonth() + 1, date2 = date.getDate(), hours = date.getHours(), minutes = date.getMinutes(), seconds = date.getSeconds();

		replacer(/yyyy/g, pad(year, 4));
		replacer(/yy/g, pad(parseInt(year.toString().slice(2), 10), 2));
		replacer(/MM/g, pad(month, 2));
		replacer(/M/g, month);
		replacer(/dd/g, pad(date2, 2));
		replacer(/d/g, date2);

		replacer(/HH/g, pad(hours, 2));
		replacer(/H/g, hours);
		replacer(/hh/g, pad(hours % 12, 2));
		replacer(/h/g, hours % 12);
		replacer(/mm/g, pad(minutes, 2));
		replacer(/m/g, minutes);
		replacer(/ss/g, pad(seconds, 2));
		replacer(/s/g, seconds);

		return pattern;

	},
	/**
	 * 将目标字符串转换成日期对象
	 * @param {string} source 目标字符串
	 * @return {Date} 转换后的日期对象
	 * <p>可转换日期格式:</p>
	 * <p>-2010/5/10</p>
	 * <p>-July,2010,3,23:</p>
	 * <p>-Tuesday November 9 1996 7:30 PM</p>
	 * <p>-2010-01-01 12:23:39</p>
	 */
	parse : function(source) {
		var reg = new RegExp("^\\d+(\\-|\\/)\\d+(\\-|\\/)\\d+\\$");
		if('string' === typeof source) {
			if(reg.test(source) || isNaN(Date.parse(source))) {
				var d = source.split(/ |T/), d1 = d.length > 1 ? d[1].split(/[^\d]/) : [0, 0, 0], d0 = d[0].split(/[^\d]/);
				return new Date(d0[0] - 0, d0[1] - 1, d0[2] - 0, d1[0] - 0, d1[1] - 0, d1[2] - 0);
			} else {
				return new Date(source);
			}
		}

		return new Date();
	}
};

/**
 * URL格式数据处理工具类
 * @class fastDev.Util.UrlUtil
 * @author 袁刚
 * @singleton
 */
fastDev.Util.UrlUtil = {
	/**
	 * 根据参数名从目标URL中获取参数值
	 * @param {string} url url地址
	 * @param {string} key 要获取的参数名
	 * @return {String|null}
	 */
	getQueryValue : function(url, key) {
		var reg = new RegExp("(^|&|\\?|#)" + fastDev.Util.StringUtil.escapeReg(key) + "=([^&#]*)(&|\\$|#)", "");
		var match = url.match(reg);
		if(match) {
			return match[2];
		}
		return null;
	},
	/**
	 * 将json对象解析成地址栏参数格式字符串,特殊字符将被被编码
	 * @param {Object} json 需要解析的json对象
	 * @param {Function} replacer_opt (Optional) 对值进行特殊处理的函数(默认采用{@link #escapeSymbol}进行处理)
	 * @return {string} - 解析结果字符串，其中值将被URI编码，{a:'&1 '} ==> "a=%261%20"。
	 */
	jsonToQuery : function(json, replacer_opt) {
		var result = [], itemLen, replacer = replacer_opt ||
		function(value) {
			return fastDev.Util.UrlUtil.escapeSymbol(value);
		};

		fastDev.each(json, function( key,item) {
			if(fastDev.isArray(item)) {
				itemLen = item.length;
				while(itemLen--) {
					result.push(key + '=' + replacer(item[itemLen], key));
				}
			} else {
				result.push(key + '=' + replacer(item, key));
			}
		});

		return result.join('&');
	},
	/**
	 * 解析目标URL中的参数成json对象
	 * @param {string} url 地址字符串
	 * @return {JsonObject}
	 */
	queryToJson : function(url) {
		var query = url.substr(url.lastIndexOf('?') + 1), params = query.split('&'), len = params.length, result = {}, i = 0, key, value, item, param;

		for(; i < len; i++) {
			if(!params[i]) {
				continue;
			}
			param = params[i].split('=');
			key = param[0];
			value = param[1];

			item = result[key];
			if('undefined' === typeof item) {
				result[key] = value;
			} else if(fastDev.ArrayUtil.isArray(item)) {
				item.push(value);
			} else {// 这里只可能是string了
				result[key] = [item, value];
			}
		}

		return result;
	},
	/**
	 * 对字符串进行%#&+=以及和\s匹配的所有字符进行url转义
	 * @param {string} source 需要转义的字符串.
	 * @return {string}
	 */
	escapeSymbol : function(source) {

		return String(source).replace(/[#%&+=\/\\\ \　\f\r\n\t]/g, function(all) {
			return '%' + (0x100 + all.charCodeAt()).toString(16).substring(1).toUpperCase();
		});
	}
};

/**
 * json工具类
 * @class fastDev.Util.JsonUtil
 * @author 袁刚
 * @singleton
 */
fastDev.Util.JsonUtil = {
	parseJson : function(str) {
		if(!str) {
			return null;
		}
		if( typeof str === "string") {
			str = fastDev.Util.StringUtil.trim(str.replace(/\s|\n|\r/g, ""));
		} else {
			return str;
		}
		try{
			if(window.JSON && window.JSON.parse) {
				return window.JSON.parse(str);
			}
		}catch(e){}
		
		if(/^\[.*\]$|^\{.*\}$/.test(str)) {
			return fastDev.Util.ObjectUtil.parseObject(str);
			//return (new Function("return " + str))();
		}else{
			throw "数据格式错误[str]";
		}
	}
};

/**
 * 对象处理工具类
 * @class fastDev.Util.ObjectUtil
 * @author 袁刚
 * @singleton
 */
fastDev.Util.ObjectUtil = {
	/**
	 * 将字符串转换为对象
	 * @param {String} str
	 * @return {Object}
	 */
	parseObject : function(str){
		//debugger;
		return new Function("return ("+str+")")();
	}	
};
