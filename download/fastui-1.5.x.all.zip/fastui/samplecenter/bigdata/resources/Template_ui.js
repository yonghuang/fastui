/**
 *	控件展现模板实现，负责解析控件内定义的界面规则并生成对应的Element
 * @class fastDev.Core.Template
 * @extends fastDev.Core.Base
 * @author  袁刚
 */

/**
 * @method destroy
 * @private
 */
fastDev.define("fastDev.Core.Template", {
	extend : "fastDev.Core.Base",
	alias : "Template",
	_options : {
		/**
		 * @type {Array[String]} 模板语句数组
		 */
		htmlList : null,
		/**
		 * @type {JsonObject} 模板中用到的参数存储对象
		 */
		params : null,
		/**
		 * 解析数据类型
		 * @type {String} dataset{fastDev.Data.DataSet} or normal{Array[JsonObject]}
		 */
		parseType : "dataset"
	},
	_global : {
		staticTpl : null,
		dynamicTpl : null
	},
	_eachCount : 0,
	_tplTag : /(?:<tpl\s(dynamic|each|if|else\sif|else)\s*([^>]*)\>)|(?:<\/tpl>)|\{([^\}]*)\}/g,
	_captureDynamicName : /name\s*=\s*(.*)/,
	_tagHandle : {

	},
	/**
	 * 模板初始化方法
	 * @param {Object} options 当前控件配置信息
	 * @param {Object} global 当前控件全局信息
	 * @protected
	 */
	ready : function(options, global) {
		// 初始化动态模板存储空间
		global.dynamicTpl = {};
		// load plugin
	},
	/**
	 * 模板构造方法
	 * @param {Object} options 当前控件配置信息
	 * @param {Object} global 当前控件全局信息
	 * @protected
	 */
	construct : function(options, global) {
		// 编译生成模板静态标签部分
		var handleStr = this.compile(options.htmlList.join(""));
		
		handleStr = this.doParamReplace(handleStr);
		
		try {
			global.staticTpl = new Function(handleStr);
		} catch(e) {

			throw "静态模板解析错误[" + e + "]";
		}

	},
	/**
	 * 字符串模板编译函数
	 * @param {String} str 模板字符串
	 * @param {JsonObject} params 参数存储对象
	 * @param {Number} index 定义模板检测正则的起始位置
	 * @param {Boolean} capture 标识当前是否在执行动态模板内容捕获
	 * @private
	 */
	compile : function(str, params, index, capture) {
		// 初始化模板生成函数内容
		var body = this.initBody(),
		// 定义编译过程中需要用到的变量
		begin, end, len = str.length, level = 0,
		// 将模板检测正则作用域降至当前函数
		tplTag = this._tplTag,
		// 数据解析器
		parseData, tag, eachStart = false;
		// 没有设置正则起始位置时从下标0开始检测执行
		index = index || 0;

		parseData = this._options.parseType === "normal" ? this.parseData : this.parseDataSet;

		// 每次正则匹配的字符串结束下标作为下次匹配的起始位置
		for(; index < len; index = end) {
			// 开始匹配模板字符串
			tplTag.lastIndex = index;
			var m = tplTag.exec(str), next = false;

			// 如果匹配不到模板关键词则断定字符串从当前匹配下标至最后都为普通文本
			if(m == null) {
				this.parseHTML(body, str.substring(index, len));
				break;
			}

			begin = m.index;
			end = tplTag.lastIndex;

			// 如果是动态模板执行捕获内容时则返回动态模板结束标记下标
			if(capture === true) {
				if(m[0] === "</tpl>") {
					if(level === 0) {
						return end;
					}
					level--;
				}
				if(m[1] && !/else/.test(m[1])) {
					level++;
				}
				continue;
			}

			// 对捕获到的参数占位符做无效处理
			if(begin!==0 && str.indexOf("#", begin - 1) === begin - 1) {
				begin = end;
				next = true;
			}

			// 添加上次捕获下标与当前捕获下标中间的非模板文本
			if(index < begin) {
				this.parseHTML(body, str.substring(index, begin));
				if(next === true) {
					continue;
				}
			}

			if( tag = m[1]) {
				if(!/else/.test(tag)){
					level++;
				}
				switch(tag) {
					case "dynamic":
						end = this.parseDynamic(body, str, m[2], end);
						break;
					case "each" :
						eachStart = true;
						this.parseEach(body, m[2]);
						break;
					case "if":
						this.parseIf(body, m[2], eachStart);
						break;
					case "else if":
						this.parseElseIf(body, m[2], eachStart);
						break;
					case "else":
						this.parseElse(body);
						break;
				}
			} else if(m[3]) {
				parseData.call(this, body, m[3]);
			} else if(m[0] === "</tpl>") {
				if(level === 0) {
					break;
				}
				body.push("}\n");
				level--;
			}

		}

		body.push("return html.join('');");

		// 将模板中的参数占位符替换为具体参数值
		return body.join("");
	},
	/**
	 * 初始化模板闭包内容 
	 */
	initBody : function() {
		return ["var html=[],tpl_count="+((this._options.params||{}).tpl_count||0)+";\n"];
	},
	/**
	 * 执行参数占位符替换
	 * @param {String} str 待替换字符串
	 * @param {JsonObject} params 参数对象
	 */
	doParamReplace : function(str, params) {
		params =  this._options.params || {};
		var value;
		return str.replace(/#\{([^\}]*)\}/g, function() {
			value = params[arguments[1]];
			if(value && value.replace){
				value = value.replace(/[\r\n\t]/ig,"");
			}
			return ( typeof value === "object" || value == null) ? !!value : value;
		});
	},
	/**
	 * 执行数据占位符替换
	 * @param {String} str 待替换字符串
	 */
	doDataReplace : function(str) {
		var m,loopCount = this._eachCount - 1,content;
		
		if(m = /{(row_id|curr_data)}/.exec(str)){
			switch(m[1]){
				case "row_id" :
					content = "(tpl_count+i"+loopCount+"+1)"; 
					break;
				case "curr_data":
					content = "dataList[i"+loopCount+"]";
					break;
			}
		}
		return str.replace(/\{([^\}]*)\}/g,function(){
			return content || "data"+loopCount+".get('" + arguments[1] + "')";
		});
	},
	/**
	 * 解析HTML字符串 
	 */
	parseHTML : function(body, str) {
		body.push("html.push('" + str + "');\n");
	},
	/**
	 * 解析数据 
	 */
	parseData : function(body, str) {
		var data = "data" + (this._eachCount - 1);
		body.push("html.push(" + data + "['" + str + "']);\n");
	},
	/**
	 * 解析数据集 
	 */
	parseDataSet : function(body, str) {
		if(/^(curr_data)$/.test(str)){
			str = "{"+str + "}";
		}else{
			str = "html.push({"+str+"});\n";
		}
		str = this.doDataReplace(str);
		body.push(str);
		
	},
	/**
	 * 解析动态模板 
	 */
	parseDynamic : function(body, str, info, index) {
		var name = this._captureDynamicName.exec(info) ? RegExp.$1 : "tpl" + fastDev.getID(),
		// 为动态模板建立单独的函数解析
		end = this.compile(str, null, index, true);
		// 保存解析函数
		this._global.dynamicTpl[name] = str.substring(index, end);
		// 在页面上建立模板占位标签
		body.push("html.push('<a name=\"" + name + "\"></a>');\n");
		// 返回动态模板结束下标
		return end;
	},
	/**
	 * 解析循环语句 
	 */
	parseEach : function(body) {
		// 防止解析函数中的循环变量重名
		var eachCount = this._eachCount++,
		// 定义循环变量
		i = "i" + eachCount, len = "len" + eachCount, data = "data" + eachCount;
		body.push("var " + i + " = 0," + len + " = dataList.length," + data + ";\n");
		body.push("for(;" + i + "<" + len + ";" + i + "++){\n");
		body.push(data + " = dataList[" + i + "];\n");
	},
	/**
	 * 解析条件判断语句 
	 */
	parseIf : function(body, info, eachStart) {
		if(eachStart === true) {
			info = this.doDataReplace(info, "data" + (this._eachCount - 1));
		}
		info = info.replace(/&lt;/g, "<").replace(/&gt;/g, ">");
		body.push("if" + info + "{\n");
	},
	/**
	 * 解析条件分支判断语句 
	 */
	parseElseIf : function(body, info, eachStart) {
		this.parseIf(body, info, eachStart);
		var str = body.pop();
		str = "}else " + str;
		body.push(str);
	},
	/**
	 * 解析条件分支语句
	 */
	parseElse : function(body) {
		body.push("}else{");
	},
	/**
	 * 创建静态模板Dom元素 
	 */
	createStaticHtml : function() {
		try {
			return fastDev(this._global.staticTpl());
		} catch(e) {
			throw "静态模板生成错误[" + e + "]";
		}
	},
	/**
	 * 获取动态模板
	 * @param {String} [name] 动态模板名称
	 */
	getDynamicTpl : function(name) {
		var dynamicTpl = this._global.dynamicTpl, tplStr;
		if(name != null) {
			tplStr = (dynamicTpl[name] || []);
		} else {
			for(var p in dynamicTpl) {
				name = p;
				tplStr = dynamicTpl[name];
				break;
			}
		}
		return {
			name : name,
			tplStr : tplStr
		};
	},
	/**
	 * 初始化动态模板
	 * @param {Array[fastDev.Data.Record]} 数据记录数据
	 * @param {String} [name] 动态模板名称
	 */
	initDynamic : function(dataList, name) {
		var dynamicTpl = this.getDynamicTpl(name), tplStr = dynamicTpl.tplStr;
		name = dynamicTpl.name;

		if(tplStr) {
			tplStr = this.doParamReplace(tplStr);
			var handleStr = this.compile(tplStr);
			var html = new Function("dataList",handleStr)(dataList);

			return {
				name : name,
				fragment : fastDev(html)
			};
		}
	},
	setParam : function(params){
		fastDev.apply(this._options.params,params);
	}
});

