$(function() {
	// fastDev.Core.ControlBus.bindCheckComplete(function(msg){
		// fastDev.tips(msg);
	// });
	
	// fastDev.Core.ControlBus.checkSession("timeout.json",function(msg){
		// fastDev.tips(msg);
	// });
	fastDev.Core.ControlBus.compile();
});